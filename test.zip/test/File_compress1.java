/*PROGRAM 8:  TO COMPRESS A FILE OR DIRECTORY*/
//package java_assignment.File_compress;


/*importing necessary packages*/
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipOutputStream;
import java.util.zip.ZipEntry;

/*to compress the given file*/
public class  File_compress1{
/*main*/
	public static void main(String[] args) throws FileNotFoundException, IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("\t\t 1.TO COMPRESS FILE 2.TO COMPRESS DIRECTORY");
		int op = sc.nextInt();  //1 for file and 2 for directory
		System.out.println("\t\t PLEASE GIVE THE PATH");
		String source = sc.next();
		switch (op) {
		case 1:
			GZIPFile(source);  //to zip  a file
			break;
		case 2:
			zipDirectory(source);  //to zip a directory
			break;
		}
	}
/*to zip a particular file*/
	public static void GZIPFile(String sourcePath) throws FileNotFoundException, IOException {
		File file = new File(sourcePath);
		String destPath = sourcePath + ".gz";
		

		try (
			FileOutputStream fos = new FileOutputStream(destPath);
			GZIPOutputStream gzos = new GZIPOutputStream(fos)
		) {
			writeFileToOutputStream(file, gzos);
		}
	}
	
/*to zip or compress a particular directory*/
	public static void zipDirectory(String sourcePath) throws FileNotFoundException, IOException {
		File dir = new File(sourcePath);
		List<File> allFiles = getAllFiles(dir);
		String destPath = sourcePath + ".zip";
		
		try (
			FileOutputStream fos = new FileOutputStream(destPath);
			ZipOutputStream zos = new ZipOutputStream(fos)
		) {
			for (File file : allFiles) {
				String zipFile =
					file.getCanonicalPath().substring(dir.getCanonicalPath()
							.length() + 1);
				ZipEntry ze = new ZipEntry(zipFile);
				zos.putNextEntry(ze);
				writeFileToOutputStream(file, zos);
				zos.closeEntry();
			}
		}
	}
	/*for listing all the files*/
	private static List<File> getAllFiles(File dir)
		throws FileNotFoundException {
		File[] files = dir.listFiles();
		if (files == null)
			throw new FileNotFoundException("\t\tSource directory not present");
		List<File> allFiles = new ArrayList<>();
		for (File file : files) {
			if (file.isDirectory()) {
				List<File> allFilesRecur = getAllFiles(file);
				allFiles.addAll(allFilesRecur);
			} else {
				allFiles.add(file);
			}
		}
		return allFiles;
	}
	
	private static void writeFileToOutputStream(File file,
			OutputStream os) throws FileNotFoundException, IOException {
		try (
			FileInputStream fis = new FileInputStream(file);
			BufferedInputStream bis = new BufferedInputStream(fis)
		) {
			byte[] buffer = new byte[1024];
			int nBytesRead;
			while ((nBytesRead = bis.read(buffer, 0, buffer.length)) >= 0) {
				os.write(buffer, 0, nBytesRead);
			} 
		};
	}
}//class ends
