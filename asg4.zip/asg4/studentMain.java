package student;

import java.util.*;



public class studentMain{
	public static void main(String[] args) {
		menu();
	}
	public static void menu(){
		Scanner sc = new Scanner(System.in);
      		//fetch student record based on his roll no from the database
      		
      		//Create a view : to write student details on console
      		studentView view = new studentView();
		ArrayList <studentController> list = new ArrayList <studentController>();
		int choice=1,roll1=0;boolean flag=false;
		studentController controller;
		while(true){
			System.out.println("\n************* Main Menu ********************\n");
			System.out.println("Enter 1 to input student");
			System.out.println("Enter 2 to display all students");
			System.out.println("Enter 3 to display a particular student");
			System.out.println("Enter 4 to remove a particular student");
			System.out.println("Enter 5 to Update the marks of a student"); 
			System.out.println("Enter 6 to exit program");
			System.out.println("\n*********************************************\n");	
			System.out.println("Enter choice : ");
			choice=sc.nextInt();
			switch(choice){
					studentModel model  = new studentModel();
					
				case 1 :studentModel model  = new studentModel();
					list.add((new studentController(model,view)).input());
					break;

				case 2 :for(int i=0;i<list.size();i++){
						controller  = new studentController(model,view);
						controller=list.get(i);
						controller.show_for_all();
					}
					break;
				case 3 :flag=false;controller  = new studentController(model,view);
					System.out.println("\nEnter Roll Number of Student :");
					roll1=sc.nextInt();
					for(int i=0;i<list.size();i++){
						controller=list.get(i);
						if(controller.compare_roll(roll1)){
							controller.show();
							flag=true;
						break;
						}
					}
					if(!flag)
						System.out.println("Roll Number Does NOT exist !!");
					break;
				case 4:controller  = new studentController(model,view);
					System.out.println("\nEnter Roll Number of Student :");
					roll1=sc.nextInt();
					flag=false;
					for(int i=0;i<list.size();i++){
						controller=list.get(i);
						if(controller.compare_roll(roll1)){
							list.remove(i);
							flag=true;
							break;
						}
					}
					if(!flag)
						System.out.println("Roll Number Does NOT exist !!");
					break;
				case 5:
					controller  = new studentController(model,view);
					System.out.println("\nEnter Roll Number of Student :");
					roll1=sc.nextInt();
					flag=false;
					for(int i=0;i<list.size();i++){
						controller=list.get(i);
						if(controller.compare_roll(roll1)){
							controller.change_marks();
							flag=true;
							break;
						}
					}
					if(!flag)
						System.out.println("Roll Number Does NOT exist !!");
					break;
				case 6:
					System.out.println("Exiting !!!");
					System.exit(0);
					break;
				default:
					System.out.println("Wrong Input !!");
					break;
				}
			}
		}
}
