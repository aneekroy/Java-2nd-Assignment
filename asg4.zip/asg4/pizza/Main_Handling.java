package lesson1;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main_Handling {

	public static void main(String[] args) throws NumberFormatException, IOException {
	
	RomeConcretePizzaFactory rcf = new RomeConcretePizzaFactory();
	MilanConcretePizzaFactory mcf = new MilanConcretePizzaFactory();
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	do
	{
		System.out.print("\n\t What type of pizza do you want ? : \n\t 1.RomeConcretePizzaFactory \n\t 2.MilanConcretePizzaFactory \n\t 3.Exit ");
		int choice = Integer.parseInt(br.readLine());
		
		switch(choice)
		{
			case 1:
				System.out.print("\n\t Pizza has been served ");
				rcf.For_Pepperoni();
				System.out.print(" and ");
				rcf.For_Anchovy();
				break;
			case 2:
				System.out.print("\n\t Pizza has been served ");
				mcf.For_Sausage();;
				System.out.print(" and ");
				mcf.For_Anchovy();
				break;
			case 3:
				System.out.println("\n\t Thank you.");
				System.exit(0);
			default:
				System.out.println("\n\t Invalid input.");
				break;
		}
	}while(true);
}

}
