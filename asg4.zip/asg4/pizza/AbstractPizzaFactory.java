package lesson1;

abstract class AbstractPizzaFactory {
	public abstract void For_Pepperoni();
	public abstract void For_Sausage();
	public abstract void For_Anchovy();
	
}
