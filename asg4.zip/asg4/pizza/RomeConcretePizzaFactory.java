package lesson1;

public class RomeConcretePizzaFactory extends AbstractPizzaFactory {
	
	public void For_Pepperoni()
	{
		System.out.print("with Pepperoni");
	}
	
	public void For_Sausage()
	{
	
	}
	
	public void For_Anchovy()
	{
		System.out.print("with Anchovy.");
	}

}
