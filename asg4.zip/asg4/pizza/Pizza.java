import java.util.*;
import java.io.*;
interface Topping{
       void putTopping();
}
class Pepperoni implements Topping{
      public void putTopping(){
           System.out.println("The pizza has Pepperoni topping on it");
      }
}
class Sausage implements Topping{
      public void putTopping(){
           System.out.println("The pizza has Sausage  topping on it");
      }
}
class Anchovy implements Topping{
      public void putTopping(){
           System.out.println("The pizza has Anchovy topping on it");
      }
}
abstract class PizzaFactory{
      abstract Topping getToppingType(String topping);
}
class ToppingFactory extends PizzaFactory{
     public Topping getToppingType(String topping){
            if(topping==null){
               return null;
            }
            else if(topping.equalsIgnoreCase("PEPPERONI")){
               return new Pepperoni();
            }
            else if(topping.equalsIgnoreCase("SAUSAGE")){
               return new Sausage();
            }
            else if(topping.equalsIgnoreCase("ANCHOVY")){
               return new Anchovy();
            }
            return null;
     }
}
class PizzaProducer{
     public static PizzaFactory getFactory(){
            return new ToppingFactory();
     }
}
public class Pizza{
     public static void main(String[] args){
           int choice;
           String type;
           System.out.println("Press 1 to continue");
           System.out.println("Press 2 to exit");
           Scanner scan=new Scanner(System.in);
           choice=scan.nextInt();
           while(choice!=2){
                 System.out.print("Enter type of topping : ");
                 type=scan.next();
                 PizzaFactory factory = PizzaProducer.getFactory();
                 Topping topping = factory.getToppingType(type);
                 topping.putTopping();
                 System.out.println("Press 1 to continue");
                 System.out.println("Press 2 to exit");     
                 choice=scan.nextInt();
           }
      }
}
