package lesson1;

public class MilanConcretePizzaFactory extends AbstractPizzaFactory{
	
	public void For_Pepperoni()
	{
		
	}
	
	public void For_Sausage()
	{
		System.out.print("with Sausage.");
	}
	
	public void For_Anchovy()
	{
		System.out.print("with Anchovy.");
	}

}
