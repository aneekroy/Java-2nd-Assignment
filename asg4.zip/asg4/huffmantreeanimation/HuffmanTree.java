//package huffmantreeanimation;

import java.io.*;
import java.util.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Scanner;
import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;
import javafx.stage.Stage;

/**
 *
 */
public class HuffmanTree {

    /**
     *
     */
   /* public class DataNode {
        private String  element;
        private int     frequency;
        private int     level;
        private char    type;
        private boolean isLeaf;

        DataNode(String newElement, int newFrequency) {
            this.element = newElement;
            this.frequency = newFrequency;
            this.level = 0;
            this.type  = 'X';
            this.isLeaf = true;
        }

        String element() {
            return this.element;
        }

        int frequency() {
            return this.frequency;
        }

        int level() {
            return this.level;
        }

        char type() {
            return this.type;
        }

        boolean isLeaf() {
            return this.isLeaf;
        }

        void setElement(String newElement) {
            this.element = newElement;
        }

        void setFrequency(int newFrequency) {
            this.frequency = newFrequency;
        }

        void setLevel(int newLevel) {
            this.level = newLevel;
        }

        void setType(char newType) {
            this.type = newType;
        }

        void setLeaf(boolean type) {
            this.isLeaf = type;
        }
    }
*/
/*
    public class DataNodeComparator implements Comparator<DataNode> {
        @Override
        public int compare(DataNode x, DataNode y) {
            if (x.frequency() < y.frequency()) {
                return -1;
            }

            if (x.frequency() > y.frequency()) {
                return 1;
            }

            return 0;
        }
    }
*/
/*
    public class Edge {
        private Integer from;
        private Integer to;

        public Edge(Integer to, Integer from) {
        	this.from = from;
        	this.to = to;
        }

        public int hashCode() {
        	int hashFrom = from != null ? from.hashCode() : 0;
        	int hashTo = to != null ? to.hashCode() : 0;

        	return (hashFrom + hashTo) * hashTo + hashFrom;
        }

        public boolean equals(Object other) {
        	if (other instanceof Edge) {
        		Edge otherPair = (Edge) other;
        		return
        		((  this.from == otherPair.from ||
        			( this.from != null && otherPair.from != null &&
        			  this.from.equals(otherPair.from))) &&
        		 (	this.to == otherPair.to ||
        			( this.to != null && otherPair.to != null &&
        			  this.to.equals(otherPair.to))) );
        	}

        	return false;
        }

        public Integer getFrom() {
        	return from;
        }

        public void setFrom(Integer from) {
        	this.from = from;
        }

        public Integer getTo() {
        	return to;
        }

        public void setTo(Integer to) {
        	this.to = to;
        }
    }
*/
    private String text;
    private TreeMap<Character, DataNode> frequencyList;
    private HashMap<Integer, DataNode> nodeList;
    private TreeSet<Edge> childList;
    private TreeSet<Edge> parentList;


/*    public class EdgeDecreasingComparator implements Comparator<Edge> {
        @Override
        public int compare(Edge x, Edge y) {
            String xPrimaryVal = nodeList.get(x.getFrom()).element();
            String yPrimaryVal = nodeList.get(y.getFrom()).element();
            String xSecondaryVal = nodeList.get(x.getTo()).element();
            String ySecondaryVal = nodeList.get(y.getTo()).element();

            if (xPrimaryVal.length() > yPrimaryVal.length()) {
                return -1;
            }
            else if (xPrimaryVal.length() < yPrimaryVal.length()) {
                return 1;
            }
            else if(xPrimaryVal.compareTo(yPrimaryVal) != 0) {
                return -xPrimaryVal.compareTo(yPrimaryVal);
            }
            else if (xSecondaryVal.length() > ySecondaryVal.length()) {
                return -1;
            }
            else if (xSecondaryVal.length() < ySecondaryVal.length()) {
                return 1;
            }
            else {
                return -xSecondaryVal.compareTo(ySecondaryVal);
            }
        }
    }
*/
  /* public class EdgeIncreasingComparator implements Comparator<Edge> {
        @Override
        public int compare(Edge x, Edge y) {
            String xPrimaryVal = nodeList.get(x.getFrom()).element();
            String yPrimaryVal = nodeList.get(y.getFrom()).element();
            String xSecondaryVal = nodeList.get(x.getTo()).element();
            String ySecondaryVal = nodeList.get(y.getTo()).element();

            if (xPrimaryVal.length() > yPrimaryVal.length()) {
                return 1;
            }
            else if (xPrimaryVal.length() < yPrimaryVal.length()) {
                return -1;
            }
            else if(xPrimaryVal.compareTo(yPrimaryVal) != 0) {
                return xPrimaryVal.compareTo(yPrimaryVal);
            }
            else if (xSecondaryVal.length() > ySecondaryVal.length()) {
                return 1;
            }
            else if (xSecondaryVal.length() < ySecondaryVal.length()) {
                return -1;
            }
            else {
                return xSecondaryVal.compareTo(ySecondaryVal);
            }
        }
    }
*/

    HuffmanTree(String sourceText) {
        text = sourceText;

        frequencyList = new TreeMap<Character, DataNode>();
        buildFrequencyList();

        nodeList = new HashMap<Integer, DataNode>();
        Comparator<Edge> topEdge = new EdgeDecreasingComparator();
        Comparator<Edge> bottomEdge = new EdgeIncreasingComparator();
        childList = new TreeSet<Edge>(topEdge);
        parentList = new TreeSet<Edge>(bottomEdge);
        buildTree();
    }

    public void buildFrequencyList() {
        for (int i = 0; i < text.length(); ++i) {
            String currKey = String.valueOf(text.charAt(i));
            DataNode currVal = frequencyList.get(text.charAt(i));

            if (currVal != null) {
                currVal.setFrequency(currVal.frequency() + 1);
            }
            else {
                frequencyList.put(text.charAt(i), new DataNode(currKey, 1));
            }
        }
    }

    public void printFrequencyList() {
        for (Map.Entry<Character, DataNode> entry : frequencyList.entrySet()) {
            Character c = entry.getKey();
            int freq = entry.getValue().frequency();

            System.out.println(c + ": " + freq);
        }
        System.out.println('\n');
    }

   public void buildTree() {
        Comparator<DataNode> cmp = new DataNodeComparator();
        PriorityQueue<DataNode> queue = new PriorityQueue<DataNode>(30,cmp);

        for (Map.Entry<Character,DataNode> entry : frequencyList.entrySet()) {
            queue.add(entry.getValue());
        }

        while(queue.size() != 1) {

            DataNode leftChild  = queue.remove();
            DataNode rightChild = queue.remove();

            Integer leftChildCode  = leftChild.element().hashCode();
            Integer rightChildCode = rightChild.element().hashCode();

            leftChild.setType('L');
            rightChild.setType('R');

            String parentElement = leftChild.element() + rightChild.element();
            int parentFrequency = leftChild.frequency() + rightChild.frequency();

            DataNode parentNode = new DataNode(parentElement, parentFrequency);
            parentNode.setLevel(Math.max(leftChild.level(), rightChild.level()) + 1);
            parentNode.setLeaf(false);

            leftChild.setLevel(parentNode.level() - 1);
            rightChild.setLevel(parentNode.level() - 1);

            queue.add(parentNode);

            Integer parentCode = parentElement.hashCode();
            nodeList.put(parentCode,parentNode);

            nodeList.put(leftChildCode, leftChild);
            nodeList.put(rightChildCode, rightChild);

            childList.add(new Edge(leftChildCode, parentCode));
            childList.add(new Edge(rightChildCode, parentCode));

            parentList.add(new Edge(leftChildCode, parentCode));
            parentList.add(new Edge(rightChildCode, parentCode));
        }

        for (Edge entry : childList) {
            Integer key = entry.getFrom();
            Integer val = entry.getTo();

            nodeList.get(val).setLevel(nodeList.get(key).level() - 1);
        }

    }

  public  void printEdgeList() {
        System.out.println(childList.size());
        for (Edge entry : childList) {
            Integer key = entry.getFrom();
            Integer val = entry.getTo();

            System.out.println(nodeList.get(key).element() + " (" + nodeList.get(key).type() + ") : " + nodeList.get(val).element());
        }
    }


    public static void main(String[] args) {
        HuffmanTree trialTree = new HuffmanTree("AAAABBBBBCCDDDDEGFHK");
    }

    public String text() {
        return text;
    }

    public TreeMap<Character, DataNode> frequencyList() {
        return frequencyList;
    }

    public HashMap<Integer, DataNode> nodeList() {
        return nodeList;
    }

    public TreeSet<Edge> childList() {
        return childList;
    }

    public TreeSet<Edge> parentList() {
        return parentList;
    }
}

// end of huffman

 public class DataNode {
        private String  element;
        private int     frequency;
        private int     level;
        private char    type;
        private boolean isLeaf;

        DataNode(String newElement, int newFrequency) {
            this.element = newElement;
            this.frequency = newFrequency;
            this.level = 0;
            this.type  = 'X';
            this.isLeaf = true;
        }

        String element() {
            return this.element;
        }

        int frequency() {
            return this.frequency;
        }

        int level() {
            return this.level;
        }

        char type() {
            return this.type;
        }

        boolean isLeaf() {
            return this.isLeaf;
        }

        void setElement(String newElement) {
            this.element = newElement;
        }

        void setFrequency(int newFrequency) {
            this.frequency = newFrequency;
        }

        void setLevel(int newLevel) {
            this.level = newLevel;
        }

        void setType(char newType) {
            this.type = newType;
        }

        void setLeaf(boolean type) {
            this.isLeaf = type;
        }
    }

// 1st class

    public class DataNodeComparator implements Comparator<DataNode> {
        @Override
        public int compare(DataNode x, DataNode y) {
            if (x.frequency() < y.frequency()) {
                return -1;
            }

            if (x.frequency() > y.frequency()) {
                return 1;
            }

            return 0;
        }
    }
//2nd class
 public class EdgeDecreasingComparator implements Comparator<Edge> {
        @Override
        public int compare(Edge x, Edge y) {
            String xPrimaryVal = nodeList.get(x.getFrom()).element();
            String yPrimaryVal = nodeList.get(y.getFrom()).element();
            String xSecondaryVal = nodeList.get(x.getTo()).element();
            String ySecondaryVal = nodeList.get(y.getTo()).element();

            if (xPrimaryVal.length() > yPrimaryVal.length()) {
                return -1;
            }
            else if (xPrimaryVal.length() < yPrimaryVal.length()) {
                return 1;
            }
            else if(xPrimaryVal.compareTo(yPrimaryVal) != 0) {
                return -xPrimaryVal.compareTo(yPrimaryVal);
            }
            else if (xSecondaryVal.length() > ySecondaryVal.length()) {
                return -1;
            }
            else if (xSecondaryVal.length() < ySecondaryVal.length()) {
                return 1;
            }
            else {
                return -xSecondaryVal.compareTo(ySecondaryVal);
            }
        }
    }

//3rd class
 public class EdgeIncreasingComparator implements Comparator<Edge> {
        @Override
        public int compare(Edge x, Edge y) {
            String xPrimaryVal = nodeList.get(x.getFrom()).element();
            String yPrimaryVal = nodeList.get(y.getFrom()).element();
            String xSecondaryVal = nodeList.get(x.getTo()).element();
            String ySecondaryVal = nodeList.get(y.getTo()).element();

            if (xPrimaryVal.length() > yPrimaryVal.length()) {
                return 1;
            }
            else if (xPrimaryVal.length() < yPrimaryVal.length()) {
                return -1;
            }
            else if(xPrimaryVal.compareTo(yPrimaryVal) != 0) {
                return xPrimaryVal.compareTo(yPrimaryVal);
            }
            else if (xSecondaryVal.length() > ySecondaryVal.length()) {
                return 1;
            }
            else if (xSecondaryVal.length() < ySecondaryVal.length()) {
                return -1;
            }
            else {
                return xSecondaryVal.compareTo(ySecondaryVal);
            }
        }
    }

//4th class


  public class Edge {
        private Integer from;
        private Integer to;

        public Edge(Integer to, Integer from) {
        	this.from = from;
        	this.to = to;
        }

        public int hashCode() {
        	int hashFrom = from != null ? from.hashCode() : 0;
        	int hashTo = to != null ? to.hashCode() : 0;

        	return (hashFrom + hashTo) * hashTo + hashFrom;
        }

        public boolean equals(Object other) {
        	if (other instanceof Edge) {
        		Edge otherPair = (Edge) other;
        		return
        		((  this.from == otherPair.from ||
        			( this.from != null && otherPair.from != null &&
        			  this.from.equals(otherPair.from))) &&
        		 (	this.to == otherPair.to ||
        			( this.to != null && otherPair.to != null &&
        			  this.to.equals(otherPair.to))) );
        	}

        	return false;
        }

        public Integer getFrom() {
        	return from;
        }

        public void setFrom(Integer from) {
        	this.from = from;
        }

        public Integer getTo() {
        	return to;
        }

        public void setTo(Integer to) {
        	this.to = to;
        }
    }

class Position {
    private Integer x;
    private Integer y;

    public Position(Integer x, Integer y) {
        this.x = x;
        this.y = y;
    }

    public int hashCode() {
        int hashX = x != null ? x.hashCode() : 0;
        int hashY = y != null ? y.hashCode() : 0;

        return (hashX + hashY) * hashY + hashX;
    }

    public boolean equals(Object other) {
        if (other instanceof Position) {
            Position otherPair = (Position) other;
            return
            ((  this.x == otherPair.x ||
                ( this.x != null && otherPair.x != null &&
                  this.x.equals(otherPair.x))) &&
             (	this.y == otherPair.y ||
                ( this.y != null && otherPair.y != null &&
                  this.y.equals(otherPair.y))) );
        }

        return false;
    }

    public Integer getX() {
        return x;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer y) {
        this.y = y;
    }
}

public class MainClass extends Application {

    private String text;
    private TreeMap<Character, DataNode> frequencyList;
    private HashMap<Integer, DataNode> nodeList;
    private TreeSet<Edge> childList;
    private TreeSet<Edge> parentList;
    private HashMap<Integer, Position> positionData = new HashMap<Integer, Position>();

    final private int LEFT = 25;
    final private int RIGHT = 1325;
    final private int TOP = 25;
    final private int BOTTOM = 725;
    final private int RADIUS = 4;


    @Override
    public void init() {
	Scanner input_getter = new Scanner(System.in);
	String 	s = input_getter.nextLine();
        HuffmanTree treeData = new HuffmanTree(s);

        text          = treeData.text();
        frequencyList = treeData.frequencyList();
        nodeList      = treeData.nodeList();
        childList     = treeData.childList();
        parentList    = treeData.parentList();

        int maxLevel = 0;
        for (Map.Entry<Integer, DataNode> entry : nodeList.entrySet()) {
            if (entry.getValue().level() > maxLevel) {
                maxLevel = entry.getValue().level();
            }
        }

        int TOPGAP = (BOTTOM - TOP) / maxLevel;

        for (Edge edge : childList) {
            if (nodeList.get(edge.getFrom()).type() == 'X') {
                positionData.put(edge.getFrom(), new Position((RIGHT-LEFT) / 2, TOP));
            }

            if (nodeList.get(edge.getTo()).type() == 'L') {
                Position parentPosition = positionData.get(edge.getFrom());
                int SIDEGAP = (int)((RIGHT - LEFT) / ( Math.pow(2, maxLevel - nodeList.get(edge.getTo()).level() + 1)));
                int xPosition = parentPosition.getX() - SIDEGAP/2;
                int yPosition = parentPosition.getY() + TOPGAP;
                positionData.put(edge.getTo(), new Position(xPosition, yPosition));
            }

             else if (nodeList.get(edge.getTo()).type() == 'R') {
                Position parentPosition = positionData.get(edge.getFrom());
                int SIDEGAP = (int)((RIGHT - LEFT) / ( Math.pow(2, maxLevel - nodeList.get(edge.getTo()).level() + 1)));
                int xPosition = parentPosition.getX() + SIDEGAP/2;
                int yPosition = parentPosition.getY() + TOPGAP;
                positionData.put(edge.getTo(), new Position(xPosition, yPosition));
            }
        }
    }

    @Override
    public void start(Stage huffmanShow) {
        huffmanShow.setTitle("Huffman Tree Animation");

        Group animation = new Group();
        Scene tree      = new Scene(animation);

        Canvas nodes = new Canvas(1360, 760);
        GraphicsContext nodePainter = nodes.getGraphicsContext2D();
        animateNodes(nodePainter);

        animation.getChildren().add(nodes);
        huffmanShow.setScene(tree);
        huffmanShow.show();

        huffmanShow.setScene(tree);
        huffmanShow.show();
    }


    private void animateNodes(GraphicsContext painter) {
        Task<Void> nodeAnimation = new Task<Void>() {
            @Override
            protected Void call() throws Exception {

                ArrayList<Map.Entry<Integer, Position>>
                levelSortedNodes = new ArrayList<Map.Entry<Integer, Position>>();

                for (Map.Entry<Integer, Position> entry : positionData.entrySet()) {
                    levelSortedNodes.add(entry);
                }

                Collections.sort(levelSortedNodes, new Comparator<Map.Entry<Integer, Position>>() {
                    @Override
                    public int compare( Map.Entry<Integer, Position> x,
                                        Map.Entry<Integer, Position> y) {
                        return nodeList.get(x.getKey()).frequency() - nodeList.get(y.getKey()).frequency();
                    }
                });

                for (Map.Entry<Integer, Position> entry : levelSortedNodes) {
                    Position nodePos = entry.getValue();
                    int xPos = nodePos.getX();
                    int yPos = nodePos.getY();
                    painter.setFill(Color.BLACK);
                    painter.setStroke(Color.BLACK);
                    painter.setLineWidth(5);
                    painter.strokeOval(xPos - RADIUS, yPos - RADIUS, 2 * RADIUS, 2 * RADIUS);
                    painter.fillOval(xPos - RADIUS, yPos - RADIUS, 2 * RADIUS, 2 * RADIUS);
                    painter.setFill(Color.BLACK);


                    if (nodeList.get(entry.getKey()).isLeaf()) {
                        painter.fillText(nodeList.get(entry.getKey()).element(), xPos, yPos + 3 * RADIUS);
                    }
                    else if (nodeList.get(entry.getKey()).type() == 'X') {
                        painter.fillText(String.valueOf(nodeList.get(entry.getKey()).frequency()), xPos + 4 * RADIUS, yPos);
                    }
                    else if (nodeList.get(entry.getKey()).type() == 'L') {
                        painter.fillText(String.valueOf(nodeList.get(entry.getKey()).frequency()), xPos - 3 * RADIUS, yPos - RADIUS);
                    }
                    else if (nodeList.get(entry.getKey()).type() == 'R') {
                        painter.fillText(String.valueOf(nodeList.get(entry.getKey()).frequency()), xPos + 2 * RADIUS, yPos - RADIUS);
                    }

                    try {
                        Thread.sleep(500);
                    }
                    catch (InterruptedException e) {
                    }
                }

                for (Edge edge : parentList) {
                    painter.strokeLine(positionData.get(edge.getFrom()).getX(),
                                       positionData.get(edge.getFrom()).getY(),
                                       positionData.get(edge.getTo()).getX(),
                                       positionData.get(edge.getTo()).getY());

                    try {
                        Thread.sleep(500);
                    }
                    catch (InterruptedException e) {
                    }
                }
                return null;
            }
        };
        new Thread(nodeAnimation).start();
    }
}
