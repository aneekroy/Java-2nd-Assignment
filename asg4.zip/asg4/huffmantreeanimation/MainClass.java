//package huffmantreeanimation;

//import huffmantreeanimation.HuffmanTree;
//import huffmantreeanimation.HuffmanTree.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Scanner;
import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;
import javafx.stage.Stage;

class Position {
    private Integer x;
    private Integer y;

    public Position(Integer x, Integer y) {
        this.x = x;
        this.y = y;
    }

    public int hashCode() {
        int hashX = x != null ? x.hashCode() : 0;
        int hashY = y != null ? y.hashCode() : 0;

        return (hashX + hashY) * hashY + hashX;
    }

    public boolean equals(Object other) {
        if (other instanceof Position) {
            Position otherPair = (Position) other;
            return
            ((  this.x == otherPair.x ||
                ( this.x != null && otherPair.x != null &&
                  this.x.equals(otherPair.x))) &&
             (	this.y == otherPair.y ||
                ( this.y != null && otherPair.y != null &&
                  this.y.equals(otherPair.y))) );
        }

        return false;
    }

    public Integer getX() {
        return x;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer y) {
        this.y = y;
    }
}

public class MainClass extends Application {

    private String text;
    private TreeMap<Character, DataNode> frequencyList;
    private HashMap<Integer, DataNode> nodeList;
    private TreeSet<Edge> childList;
    private TreeSet<Edge> parentList;
    private HashMap<Integer, Position> positionData = new HashMap<Integer, Position>();

    final private int LEFT = 25;
    final private int RIGHT = 1325;
    final private int TOP = 25;
    final private int BOTTOM = 725;
    final private int RADIUS = 4;


    @Override
    public void init() {
	Scanner input_getter = new Scanner(System.in);
	String 	s = input_getter.nextLine();
        HuffmanTree treeData = new HuffmanTree(s);

        text          = treeData.text();
        frequencyList = treeData.frequencyList();
        nodeList      = treeData.nodeList();
        childList     = treeData.childList();
        parentList    = treeData.parentList();

        int maxLevel = 0;
        for (Map.Entry<Integer, DataNode> entry : nodeList.entrySet()) {
            if (entry.getValue().level() > maxLevel) {
                maxLevel = entry.getValue().level();
            }
        }

        int TOPGAP = (BOTTOM - TOP) / maxLevel;

        for (Edge edge : childList) {
            if (nodeList.get(edge.getFrom()).type() == 'X') {
                positionData.put(edge.getFrom(), new Position((RIGHT-LEFT) / 2, TOP));
            }

            if (nodeList.get(edge.getTo()).type() == 'L') {
                Position parentPosition = positionData.get(edge.getFrom());
                int SIDEGAP = (int)((RIGHT - LEFT) / ( Math.pow(2, maxLevel - nodeList.get(edge.getTo()).level() + 1)));
                int xPosition = parentPosition.getX() - SIDEGAP/2;
                int yPosition = parentPosition.getY() + TOPGAP;
                positionData.put(edge.getTo(), new Position(xPosition, yPosition));
            }

             else if (nodeList.get(edge.getTo()).type() == 'R') {
                Position parentPosition = positionData.get(edge.getFrom());
                int SIDEGAP = (int)((RIGHT - LEFT) / ( Math.pow(2, maxLevel - nodeList.get(edge.getTo()).level() + 1)));
                int xPosition = parentPosition.getX() + SIDEGAP/2;
                int yPosition = parentPosition.getY() + TOPGAP;
                positionData.put(edge.getTo(), new Position(xPosition, yPosition));
            }
        }
    }

    @Override
    public void start(Stage huffmanShow) {
        huffmanShow.setTitle("Huffman Tree Animation");

        Group animation = new Group();
        Scene tree      = new Scene(animation);

        Canvas nodes = new Canvas(1360, 760);
        GraphicsContext nodePainter = nodes.getGraphicsContext2D();
        animateNodes(nodePainter);

        animation.getChildren().add(nodes);
        huffmanShow.setScene(tree);
        huffmanShow.show();

        huffmanShow.setScene(tree);
        huffmanShow.show();
    }


    private void animateNodes(GraphicsContext painter) {
        Task<Void> nodeAnimation = new Task<Void>() {
            @Override
            protected Void call() throws Exception {

                ArrayList<Map.Entry<Integer, Position>>
                levelSortedNodes = new ArrayList<Map.Entry<Integer, Position>>();

                for (Map.Entry<Integer, Position> entry : positionData.entrySet()) {
                    levelSortedNodes.add(entry);
                }

                Collections.sort(levelSortedNodes, new Comparator<Map.Entry<Integer, Position>>() {
                    @Override
                    public int compare( Map.Entry<Integer, Position> x,
                                        Map.Entry<Integer, Position> y) {
                        return nodeList.get(x.getKey()).frequency() - nodeList.get(y.getKey()).frequency();
                    }
                });

                for (Map.Entry<Integer, Position> entry : levelSortedNodes) {
                    Position nodePos = entry.getValue();
                    int xPos = nodePos.getX();
                    int yPos = nodePos.getY();
                    painter.setFill(Color.BLACK);
                    painter.setStroke(Color.BLACK);
                    painter.setLineWidth(5);
                    painter.strokeOval(xPos - RADIUS, yPos - RADIUS, 2 * RADIUS, 2 * RADIUS);
                    painter.fillOval(xPos - RADIUS, yPos - RADIUS, 2 * RADIUS, 2 * RADIUS);
                    painter.setFill(Color.BLACK);


                    if (nodeList.get(entry.getKey()).isLeaf()) {
                        painter.fillText(nodeList.get(entry.getKey()).element(), xPos, yPos + 3 * RADIUS);
                    }
                    else if (nodeList.get(entry.getKey()).type() == 'X') {
                        painter.fillText(String.valueOf(nodeList.get(entry.getKey()).frequency()), xPos + 4 * RADIUS, yPos);
                    }
                    else if (nodeList.get(entry.getKey()).type() == 'L') {
                        painter.fillText(String.valueOf(nodeList.get(entry.getKey()).frequency()), xPos - 3 * RADIUS, yPos - RADIUS);
                    }
                    else if (nodeList.get(entry.getKey()).type() == 'R') {
                        painter.fillText(String.valueOf(nodeList.get(entry.getKey()).frequency()), xPos + 2 * RADIUS, yPos - RADIUS);
                    }

                    try {
                        Thread.sleep(500);
                    }
                    catch (InterruptedException e) {
                    }
                }

                for (Edge edge : parentList) {
                    painter.strokeLine(positionData.get(edge.getFrom()).getX(),
                                       positionData.get(edge.getFrom()).getY(),
                                       positionData.get(edge.getTo()).getX(),
                                       positionData.get(edge.getTo()).getY());

                    try {
                        Thread.sleep(500);
                    }
                    catch (InterruptedException e) {
                    }
                }
                return null;
            }
        };
        new Thread(nodeAnimation).start();
    }
}
