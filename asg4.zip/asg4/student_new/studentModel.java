package student_new;


import java.util.*;

public class studentModel {

	
		private String name;//name of student
		private	int roll;   //roll of student
		private	String date;		
		private int marks[]=new int [6];
		private	String sub[]=new String[6];
		private int total;
		private float cgpa;
		studentModel(){         // user defined constructor

			roll=0;
			name="\0";
			date="\0";
			for(int i =0;i<6;i++)marks[i]=0;			
			for(int i =0;i<6;i++)sub[i]="\0";
			total=0;
		}


		/*to get the details of a student*/
		public int get_roll(){
		
			return(roll);
		}
		public String get_date(){
			return(date);
		}
		public String get_name(){//to get  the students name

		return(name);
		}	
		public void set_date(String dat){
			date=dat;
		}
		public void set_name(String nam){
			name=nam;
		}
		public void set_roll(int roll){
		this.roll=roll;
		}
		public void set_sub_marks(int [] mar,String [] subject){
			for(int i =0;i<5;i++)
			{
				marks[i]=mar[i];			
				sub[i]=subject[i];
			}
		}
		public void display_sub_marks(){
				System.out.println("\n The subject and marks are :");
				for(int y=0;y<5;y++){
				System.out.println(sub[y]+"\t \t\t "+marks[y]);
		
			}
		}
		public String ret_sub(int code){
			return sub[code];
		}
		public int ret_marks(int code){
			return marks[code];
		}
		public void change_marks(int sub_code,int new_marks){
			if(sub_code>=0&&sub_code<5){
			marks[sub_code]=new_marks;
			System.out.println("Updated new marks for : "+sub[sub_code]+" is : "+marks[sub_code]);
			this.set_total();
			this.set_cgpa();
			}
			else 
			System.out.println(" Error!! ");
		} 
		public void set_total(){
			total =0;
			for(int i =0;i<5;i++)
				total+=marks[i];
		}
		public void set_cgpa(){
			cgpa = (float)(total/50.0);
		}
		public float get_cgpa(){return cgpa;}
		public int get_total(){
			return(total);
		}	
	}

