
package student_new;

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import java.awt.event.*;
import java.awt.EventQueue;

public class StudentView1 extends JFrame {

	private JFrame frame;
        private JButton b1;
		
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentView1 window = new StudentView1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	/**
	 * Create the application.
	 */
	public StudentView1(studentModel M) {
		initialize(M);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(studentModel M) {
		frame = new JFrame();
		//frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		 JTextField textField;
		 JTextField txtRoll;
		 JLabel lblSubjects;
		 JLabel lblMarks,lblDate,lblcgpa,lbltotal;
		 JTextField textField_1,textField_date,textField_11,textField_cgpa;
		 JTextField textField_2;
		 JTextField textField_3;
		 JTextField textField_4;
		 JTextField textField_5;
		 JTextField textField_6;
		 JTextField textField_7;
		 JTextField textField_8;
		 JTextField textField_9;
		 JTextField textField_10;
			setSize(500,500);
		
			getContentPane().setLayout(null);
			
			JLabel lblNewLabel = new JLabel("Name of the Student: ");
			lblNewLabel.setBounds(20, 35, 180, 15);
			getContentPane().add(lblNewLabel);
			//getContentPane().setLayout(new FlowLayout());
			
			
			textField = new JTextField(M.get_name());
			textField.setBounds(210, 35, 114, 19);
			getContentPane().add(textField);
			textField.setColumns(10);
			
			
			
			

			JLabel lblRoll = new JLabel("Roll :");
			lblRoll.setBounds(100, 60, 70, 15);
			getContentPane().add(lblRoll);
			
			txtRoll = new JTextField(Integer.toString(M.get_roll()));
			txtRoll.setBounds(210, 60, 114, 19);
			getContentPane().add(txtRoll);
			txtRoll.setColumns(10);

			lblDate = new JLabel("Date :");
			lblDate.setBounds(100, 100, 70, 15);
			getContentPane().add(lblDate);
						

			textField_date = new JTextField(M.get_date());
			textField_date.setBounds(210, 100, 145, 19);
			getContentPane().add(textField_date);
			textField_date.setColumns(10);
			
			lblSubjects = new JLabel("Subjects");
			lblSubjects.setBounds(64, 140, 70, 15);
			getContentPane().add(lblSubjects);
			
			lblMarks = new JLabel("Marks");
			lblMarks.setBounds(244, 140, 70, 15);
			getContentPane().add(lblMarks);
			
			textField_1 = new JTextField(M.ret_sub(0));
			textField_1.setBounds(54, 165, 114, 19);
			getContentPane().add(textField_1);
			textField_1.setColumns(10);
			
			textField_2 = new JTextField(Integer.toString(M.ret_marks(0)));
			textField_2.setBounds(234, 165, 114, 19);
			getContentPane().add(textField_2);
			textField_2.setColumns(10);
			
			textField_3 = new JTextField(M.ret_sub(1));
			textField_3.setBounds(54, 190, 114, 19);
			getContentPane().add(textField_3);
			textField_3.setColumns(10);
			
			textField_4 = new JTextField(Integer.toString(M.ret_marks(1)));
			textField_4.setBounds(234, 190, 114, 19);
			getContentPane().add(textField_4);
			textField_4.setColumns(10);
			
			textField_5 = new JTextField(M.ret_sub(2));
			textField_5.setBounds(54, 215, 114, 19);
			getContentPane().add(textField_5);
			textField_5.setColumns(10);
			
			textField_6 = new JTextField(Integer.toString(M.ret_marks(2)));
			textField_6.setBounds(234, 215, 114, 19);
			getContentPane().add(textField_6);
			textField_6.setColumns(10);
			
			textField_7 = new JTextField(M.ret_sub(3));
			textField_7.setBounds(54, 240, 114, 19);
			getContentPane().add(textField_7);
			textField_7.setColumns(10);
			
			textField_8 = new JTextField(Integer.toString(M.ret_marks(3)));
			textField_8.setBounds(234, 240, 114, 19);
			getContentPane().add(textField_8);
			textField_8.setColumns(10);
			
			textField_9 = new JTextField(M.ret_sub(4));
			textField_9.setBounds(54, 265, 114, 19);
			getContentPane().add(textField_9);
			textField_9.setColumns(10);
			
			textField_10 = new JTextField(Integer.toString(M.ret_marks(4)));
			textField_10.setBounds(234, 265, 114, 19);
			getContentPane().add(textField_10);
			textField_10.setColumns(10);
			
			lbltotal = new JLabel("Total : ");
			lbltotal.setBounds(64, 300, 114, 19);
			getContentPane().add(lbltotal);
			
			textField_11 = new JTextField(Integer.toString(M.get_total()));
			textField_11.setBounds(234, 300, 114, 19);
			getContentPane().add(textField_11);
			textField_11.setColumns(10);
			
			lblcgpa = new JLabel("CGPA : ");
			lblcgpa.setBounds(64, 325, 114, 19);
			getContentPane().add(lblcgpa);
			
			textField_cgpa = new JTextField(Float.toString(M.get_cgpa()));
			textField_cgpa.setBounds(234, 325, 114, 19);
			getContentPane().add(textField_cgpa);
			textField_cgpa.setColumns(10);
						
			
			b1 = new JButton("EXIT");
			b1.setBounds(150, 360, 114, 19);
			
			getContentPane().add(b1);
			b1.addActionListener(new mylistener());
		
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setVisible(true);
			
					
	}
private class mylistener implements ActionListener{
		
		public void actionPerformed(ActionEvent e){
			
			if(e.getSource()==b1){
				setVisible(false);
				dispose();
			}
		}
	}
/*	private JFrame getContentPane() {
		// TODO Auto-generated method stub
		return null;
	}
*/
}
