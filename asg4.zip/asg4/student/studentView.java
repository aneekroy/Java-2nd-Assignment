
package student;


import java.util.*;

public class studentView {

	/*displaying the marksheet of a particular student*/	
public void display(studentModel Obj){
		System.out.println("--------------------------MARKSHEET---------------------------------------");
		System.out.println("\n\nName : "+Obj.get_name()+"\tDate : "+Obj.get_date());
		System.out.println("---------------------------------------------------------------------------");
		System.out.println();
		System.out.println("---------------------------------------------------------------------------");
		System.out.println("ROLL NO :\t\t" +Obj.get_roll());
		System.out.println("---------------------------------------------------------------------------");
		System.out.println("SUBJECT \t\t MARKS");
		Obj.display_sub_marks();	
		System.out.println("---------------------------------------------------------------------------");
		System.out.println("TOTAL is : "+Obj.get_total()+"\t and CGPA is : "+Obj.get_cgpa());
}
public void display_for_all(studentModel Obj){
		System.out.println("--------------------------MARKSHEET---------------------------------------");
		System.out.println("\n\nName : "+Obj.get_name()+"\tDate : "+Obj.get_date());
		System.out.println("---------------------------------------------------------------------------\n");
		System.out.println("ROLL NO :\t\t" +Obj.get_roll());
		System.out.println("---------------------------------------------------------------------------");
		System.out.println("TOTAL is : "+Obj.get_total()+"\t and CGPA is : "+Obj.get_cgpa());
}

}
