//import java.util.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

class  window_demo extends JFrame{
	JLabel l1,l2,l3;
	JTextField tb1,tb2,tb3;
	JButton b1,b2;
	 private static final long serialVersionUID = 1L;
	public window_demo(){
		super("Student Admission System");
		setLayout(new FlowLayout(FlowLayout.LEADING));
		setSize(400,100);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	public void build_component(){
		l1=new JLabel("Name :");
		l2=new JLabel("Roll :");
		l3=new JLabel("Subject   Marks");
		tb1=new JTextField(10);
		tb2=new JTextField(10);	
		tb11=new JTextField(10);
		tb12=new JTextField(10);tb13=new JTextField(10);tb14=new JTextField(10);tb15=new JTextField(10);tb16=new JTextField(10);
		tb17=new JTextField(10);tb18=new JTextField(10);tb19=new JTextField(10);tb20=new JTextField(10);tb21=new JTextField(10);
		b1=new JButton("Enter");
		b2=new JButton("Go To Main Menu");
		add(l1);
		add(tb1);
		add(l2);
		add(tb2);
		add(l3);
		add(tb3);
		add(b1);
		add(b2);
		b1.addActionListener(new myListener());
		b2.addActionListener(new myListener());
		setVisible(true);
		
	}
	private class myListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			int v1,v2,v3;
			if(e.getSource()==b2){	
				System.exit(0);
			}
			if(e.getSource()==b1){
				v1=Integer.parseInt(tb1.getText());
				v2=Integer.parseInt(tb2.getText());
				v3=v1+v2;
				tb3.setText(Integer.toString(v3));
			}
		}
	}
};

public class calc_window{
public static void main(String args[]){
window_demo obj = new window_demo();
obj.build_component();
}
}

