
package student;

import java.util.*;
import java.io.*;
import java.util.Scanner;
import java.util.Date;
import java.util.Collections;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Calendar;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class studentController {
   private studentModel model;
   private studentView view ;

   public studentController(studentModel model, studentView view){
      this.model = model;
      this.view = view;
   }

public void show(){
	this.view.display(this.model);
}
public void show_for_all(){
	this.view.display_for_all(this.model);
}
public studentController input(){
		String name;//name of student
		int roll;   //roll of student
		String date;		
		int marks[]=new int [6];
		String sub[]=new String[6];
		Scanner s = new Scanner(System.in);
		int m,j;String s1;int fg=0;
		System.out.println("\t\t ENTER DETAILS OF STUDENT");
		System.out.print("Enter name:");
		name=s.nextLine();
		
	/*to check if a string contains digits or not*/
		for(int h=0;h<name.length();h++){
			if(name.charAt(h)=='1' || name.charAt(h)=='2'||name.charAt(h)=='3'||name.charAt(h)=='4'||name.charAt(h)=='5'||name.charAt(h)=='6'||name.charAt(h)=='7'||name.charAt(h)=='8'||name.charAt(h)=='9'){
				fg=1;
				System.out.println("name contains digits enter correctlty");
				break;
			}
		}
		if(fg!=1){
			System.out.print("Enter roll no:");
			roll=s.nextInt();
			System.out.println();
			/*system generated date*/
	   		SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//dd/MM/yyyy
	    		Date now = new Date();
	    		date = sdfDate.format(now);
			System.out.println("Admission Date : "+date);
			System.out.println("Enter Subject and marks :");
			/*entering the marks of the subjects*/
			for(j=0;j<5;j++){
				s1=s.next();
				m= s.nextInt();
				if(m<0 || m>100){         //marks should not > 100 or <0
					System.out.println("wrong marks entered");break;}
				sub[j]=s1;
				marks[j]=m;
				//total=total+m;
			}
			model.set_name(name);
			model.set_roll(roll);
			model.set_date(date);
			model.set_sub_marks(marks,sub);
			model.set_total();
			model.set_cgpa();
		}
		return this;
}
public boolean compare_roll(int rol){
	if(this.model.get_roll()==rol)
		return true;
	else 
		return false;
}
/*function to change the marks of any of the subjects of a particular student*/
public void change_marks(){
		int f,sub_code,new_marks;
		System.out.println("enter no of subjects whose marks needs to be changed");
		Scanner s = new Scanner(System.in);
		f=s.nextInt();
		//System.out.println("Enter subject codes");
		while(f!=0){
			System.out.println("Enter subject codes : ");		
			sub_code=s.nextInt();	
			if(sub_code>=1 && sub_code<=5){
				System.out.println("Enter new marks");
				new_marks=s.nextInt();
				if(new_marks>=0&&new_marks<101)
				model.change_marks(sub_code,new_marks);
				else
				System.out.println("Marks OUT of Range of 0 to 100");
				}
			else
				System.out.println("Wrong subject code entered");
			f--;
		}
	}

	
};


