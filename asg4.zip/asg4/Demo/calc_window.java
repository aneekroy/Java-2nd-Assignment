//import java.util.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

class  window_demo extends JFrame{
	JLabel l1,l2,l3;
	JTextField tb1,tb2,tb3;
	JButton b1,b2;
	 private static final long serialVersionUID = 1L;
	public window_demo(){
		super("Calculation");
		setLayout(new FlowLayout(FlowLayout.LEADING));
		setSize(400,100);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	public void build_component(){
		l1=new JLabel("First No.");
		l2=new JLabel("Second No.");
		l3=new JLabel("Result");
		tb1=new JTextField(10);
		tb2=new JTextField(10);	
		tb3=new JTextField(10);
		b1=new JButton("ADD");
		b2=new JButton("EXIT");
		add(l1);
		add(tb1);
		add(l2);
		add(tb2);
		add(l3);
		add(tb3);
		add(b1);
		add(b2);
		b1.addActionListener(new myListener());
		b2.addActionListener(new myListener());
		setVisible(true);
		
	}
	private class myListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			int v1,v2,v3;
			if(e.getSource()==b2){	
				System.exit(0);
			}
			if(e.getSource()==b1){
				v1=Integer.parseInt(tb1.getText());
				v2=Integer.parseInt(tb2.getText());
				v3=v1+v2;
				tb3.setText(Integer.toString(v3));
			}
		}
	}
};

public class calc_window{
public static void main(String args[]){
window_demo obj = new window_demo();
obj.build_component();
}
}

