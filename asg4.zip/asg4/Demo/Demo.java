import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

 class animation_huffman extends JFrame{
	
	JLabel l1;
	JTextField t1;
	JButton b1,b2;
	public animation_huffman(){
	
		super("STRING INPUT WINDOW");	
		setLayout(new FlowLayout());
		setSize(300,200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		build_component();
	}

	public void  build_component(){
		
		l1 = new JLabel("ENTER A STRING");
		t1 = new  JTextField(20);
		b1 = new JButton("ENTER");
		b2 = new JButton("EXIT");
		add(l1);	
		add(t1);
		add(b1);
		add(b2);
		b1.addActionListener(new mylistener());
		b2.addActionListener(new mylistener());
	}

	private class mylistener implements ActionListener{
		
		public void actionPerformed(ActionEvent e){
			
			if(e.getSource()==b2)
				System.exit(0);
			else{
				String s = t1.getText();
				//JavaSwingDrawing f = new JavaSwingDrawing();
				//f.createAndShowGUI();
				//animation_huffman  h = new animation_huffman();
        			//output.append(inputString + "\n");
         			//t2.setText("");
			}
		}
	}
}
		
	
	public class Demo {
	public static void main(String args[]){
		
		animation_huffman  h = new animation_huffman();
	}
	

}



