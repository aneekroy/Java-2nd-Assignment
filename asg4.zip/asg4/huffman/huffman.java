import java.util.*; 
class Node implements Comparable<Node> {
        private  char ch;
        private  int freq;
        private  Node left, right;

        Node(char ch, int freq, Node left, Node right) {
            this.ch    = ch;
            this.freq  = freq;
            this.left  = left;
            this.right = right;
        }

        // is the node a leaf node?
        public boolean isLeaf() {
            
            return (left == null) && (right == null);
        }

        // compare, based on frequency
        public int compareTo(Node that) {
            return Integer.compare(this.freq,that.freq);
        }
        
        public  Node getLeft(){
        	return this.left;
        }
        
        public Node getRight(){
        	return this.right;
        }
        
        public int getFreq(){
        	return this.freq;
        }
        
        public char getValue(){
        	return this.ch;
        }
        
    }

  
  
  
  class Huffman{
	  int freq[];
	  Node ht;
	  String str;
	  String table[];
	  
	 public Node buildTrie(int[] freq) {

	      
	        PriorityQueue<Node> pq = new PriorityQueue<Node>();
	        for (char i = 0; i < 256; i++)
	            if (freq[i] > 0)
	                pq.add(new Node(i, freq[i], null, null));

	   

	        // merge two smallest trees
	        while (pq.size() > 1) {
	            Node left  = pq.poll();
	            Node right = pq.poll();
	            Node parent = new Node('\0', left.getFreq() + right.getFreq(), left, right);
	            pq.add(parent);
	        }
	        return pq.poll();
	    }

	  
	  public void input(){
		  System.out.println("Enter String to encode");
		  Scanner sc= new Scanner(System.in);
		  str = sc.nextLine();
	
	       freq = new int[256];
	        for (int i = 0; i < str.length(); i++)
	            freq[str.charAt(i)]++;
	        
 
	  }
	  
	  public void compress(){
		  input();
		  ht = buildTrie(freq);
		  table=new String[256];
		  buildCode(ht, "");
		  
		  for(int i=0;i<256;i++){
			  if(table[i]==null)
				  continue;
			  else
				  System.out.println((char)i +" encoded to "+ table[i]);
			  
		  } 
			  
		  }
		  
		  
		  
		  
	  
	  
	 public void buildCode( Node x, String s) {
	        if (!x.isLeaf()) {
	            buildCode( x.getLeft(),  s + '0');
	            buildCode(x.getRight(), s + '1');
	        }
	        else {
	            table[x.getValue()] = s;
	        }
	    }
	  
	  
	  
  }