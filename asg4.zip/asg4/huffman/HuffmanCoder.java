//package huffman;

import java.util.PriorityQueue;
import java.util.Scanner;


public class HuffmanCoder {
	private static final int ALPHABET_SIZE = 256;

	public HuffmanCoder() { }

	private static class Node implements Comparable<Node> {
		private final char ch;
		private final int freq;
		private final Node left, right;

		public Node(char ch, int freq, Node left, Node right) {
			this.ch = ch;
			this.freq = freq;
			this.left = left;
			this.right = right;
		}

		private boolean isLeaf() {
			return left == null && right == null;
		}

		public int compareTo(Node that) {
			return this.freq - that.freq;
		}
	}

	public static int[] getFrequencies(String s) {
		int[] freqs = new int[ALPHABET_SIZE];
		for (char c: s.toCharArray()) {
			freqs[c]++;
		}
		return freqs;
	}

	public static Node getTree(int[] freqs) {
		PriorityQueue<Node> pq = new PriorityQueue<>();
		for (int i = 0; i < ALPHABET_SIZE; i++) {
			if (freqs[i] > 0) {
				pq.add(new Node((char)i, freqs[i], null, null));
			}
		}

		if (pq.size() == 1) {
			pq.add(new Node('\0', 0, null, null));
		}

		while (pq.size() > 1) {
			Node left = pq.poll();
			Node right = pq.poll();
			Node parent = new Node('\0', left.freq + right.freq, left, right);
			pq.add(parent);
		} 
		return pq.poll();
	}

	public static void getCodes(String[] codes, Node node, String s) {
		if (node.isLeaf()) {
			codes[node.ch] = s;
			return;
		}

		getCodes(codes, node.left, s + '0');
		getCodes(codes, node.right, s + '1');
	}

	public static void execute(String s) {
		//Scanner sc = new Scanner(System.in);
		//String s = sc.nextLine();
		int[] freqs = getFrequencies(s);

		for (int i = 0; i < freqs.length; i++) {
			if (freqs[i] > 0) {
				System.err.println((char)i + ": " + freqs[i]);
			}
		}
		
		Node root = getTree(freqs);
		String[] codes = new String[ALPHABET_SIZE];
		getCodes(codes, root, "");
		for (int i = 0; i < freqs.length; i++) {
			if (freqs[i] > 0) {
				System.out.println((char)i + ": " + codes[i]);
			}
		}
		
		
	}
}
