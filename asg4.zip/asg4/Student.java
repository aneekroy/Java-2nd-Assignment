/*MODEL  CLASS FOR STUDENT*/


import java.util.HashMap;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Set;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import java.awt.event.*;
import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
import java.io.*;

class StudentModel{

	/*the characteristics of the student*/
	
	private String name ;
	private String roll_no;
	private String course;
	private String date;
	HashMap<String,String> mp = new HashMap<String,String>();
	private String total;

/*constructor for model class*/

	public StudentModel(){
	
		SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//dd/MM/yyyy
	    	Date now = new Date();
	    	date = sdfDate.format(now);
	}
	
	public void setName(String name){
	
		this.name = name;
	}
	
	public void setroll_no(String roll){
	
		this.roll_no = roll;
	}

	public void setcourse(String course){

		this.course = course;
	}

	public void setmarks(String a,String b){
	
		mp.put(a,b);
	}

	public String get_name(){

		return(this.name);
	}
     
        public String get_roll(){

		return(this.roll_no);
	}

	public String get_course(){

		return(this.course);
	}
	
	public String get_date(){

		return(this.date);
	}
	
	public String getmarks(String a){

		return(this.mp.get(a));
	}

	public String gettotal(){
		return total;
	}

	public void calc(){
		 int s=0;
		 Set<String> keys = mp.keySet();
       		 for(String key: keys){
           		s = s + Integer.parseInt(mp.get(key));
		}
		total = Integer.toString(s);
	}

}



/*VIEW CLASS FOR STUDENT*/

//package view;



 class StudentView extends JFrame{

	JButton b1,b2;
		

	public StudentView(){
	
		super("CHOICE WINDOW");	
		setLayout(new FlowLayout());
		setSize(300,200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		build_component();
	}
	
	public void build_component(){
		b1 = new JButton("ENTER NEW STUDENT");
		b2 = new JButton("DISPLAY MARKS");
		add(b1);
		add(b2);

		
	}
	
	public JButton getButton1(){
        	return b1;
	}

	public JButton getButton2(){
        	return b2;
	}

}



//package view;
 class StudentView1 extends JFrame{

	JButton b1;
	JTextField  l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13;
	JLabel t1,t2,t3,t4,t5;

	public StudentView1(){
	
		super("ADMISSION WINDOW");	
		setLayout(new FlowLayout());
		setSize(300,400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		build_component1();
	}
	
	public void build_component1(){
		t1 = new JLabel("ENTER NAME");
		l1 = new JTextField(20);
		t2 = new JLabel("ENTER ROLL NO");
		l2 = new JTextField(20);
		t3=  new JLabel("ENTER COURSE");
		l3 = new JTextField(20);
		
		add(t1);
		add(l1);
		add(t2);
		add(l2);
		add(t3);
		add(l3);
		
		t4 = new JLabel("     SUBJECT    ");
		add(t4);
		t5= new JLabel("       MARKS     ");
		add(t5);
		l4= new JTextField(10);
		add(l4);
		l5 = new JTextField(10);
		add(l5);
	        l6= new JTextField(10);
		add(l6);
		l7 = new JTextField(10);
		add(l7);
		l8= new JTextField(10);
		add(l8);
		l9 = new JTextField(10);
		add(l9);
		l10= new JTextField(10);
		add(l10);
		l11 = new JTextField(10);
		add(l11);
		l12= new JTextField(10);
		add(l12);
		l13 = new JTextField(10);
		add(l13);
		
		
		
		b1 = new JButton("SUBMIT");
		add(b1);
		
	}

	
	public JButton getbutton(){
		return b1;
	}

	public JTextField gettext1(){
		return l1;
	}

	public JTextField gettext2(){
		return l2;
	}

	public JTextField gettext3(){
		return l3;
	}

	public JTextField gettext4(){
		return l4;
	}
	
	public JTextField gettext5(){
		return l5;
	}

	public JTextField gettext6(){
		return l6;
	}

	public JTextField gettext7(){
		return l7;
	}

	public JTextField gettext8(){
		return l8;
	}

	public JTextField gettext9(){
		return l9;
	}

	public JTextField gettext10(){
		return l10;
	}
	
	public JTextField gettext11(){
		return l11;
	}

	public JTextField gettext12(){
		return l12;
	}

	public JTextField gettext13(){
		return l13;
	}
}


class StudentView2 extends JFrame{

	JButton b1;
	JTextField  l1,l2,l3,l4,l5;
	JLabel t1,t2,t3,t4,t5;
	JTable table;	

	public StudentView2(){
	
		super("MARKSHEET");	
		setLayout(new FlowLayout());
		setSize(300,400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		build_component1();
	}
	
	public void build_component1(){
		t1 = new JLabel("NAME");
		add(t1);
		l1= new JTextField(20);
		add(l1);
		t2 = new JLabel("ROLL NO ");
		add(t2);
		l2 = new JTextField(20);
		add(l2);
		t3 = new JLabel("DATE");
		add(t3);
		l3 = new JTextField(20);
		add(l3);
		t4 = new JLabel("Course");
		add(t4);
		l4 = new JTextField(20);
		add(l4);
		
		/*t5 = new JLabel("TOTAL MARKS");
		add(t5);
		l5 = new JTextField(20);
		add(l5);*/
		
		
	}

	public JTable tab(){
		return table;
	}

	public JTextField text1(){

		return l1;
	}
	
	public JTextField text2(){

		return l2;
	}

	public JTextField text3(){

		return l4;
	}

	public JTextField text4(){

		return l3;
	}
	
	public JTextField text5(){

		return l5;
	}
	
}	

class StudentView3 extends JFrame{
	JLabel l1;
	JTextField t1;
	JButton b1;
	public StudentView3(){
	
		super("ROLL WINDOW");	
		setLayout(new FlowLayout());
		setSize(300,400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		build_component1();
	}
	
	public void build_component1(){
		l1 = new JLabel("ENTER ROLL NO");
		add(l1);
		t1= new JTextField(20);
		add(t1);
		b1 = new JButton("SUBMIT");
		add(b1);
	}

	public JTextField ret(){
		return t1;
	}

	public JButton getbutton(){
		return b1;
	}
}	


	
//package controller;



//import model.*;
//import view.*;

 class StudentController {

    private StudentModel model;
    private StudentView view;
    private StudentView1 v;
    private StudentView2 v2;
    private StudentView3 v3;
   // private StudentView v4;
    private ActionListener actionListener,actionListener1;
    private ArrayList<StudentModel> ls = new ArrayList<StudentModel>();
    
    public StudentController(StudentModel model, StudentView view){
        this.model = model;
        this.view = view;

                          
    }

public void control1(){
		v.getbutton().addActionListener(new actionListener1());
}
	        
class actionListener1 extends JFrame implements ActionListener {		
			public void actionPerformed(ActionEvent e){
                                JTable t ;
				model.setName(v.gettext1().getText());
				model.setroll_no(v.gettext2().getText());
				model.setcourse(v.gettext3().getText());
				model.setmarks(v.gettext4().getText(),v.gettext5().getText());
				model.setmarks(v.gettext6().getText(),v.gettext7().getText());
				model.setmarks(v.gettext8().getText(),v.gettext9().getText());
				model.setmarks(v.gettext10().getText(),v.gettext11().getText());
				model.setmarks(v.gettext12().getText(),v.gettext13().getText());
				model.calc();
				if(e.getSource()==v.getbutton()){
					v2 = new StudentView2();
					v2.text1().setText(model.get_name());
					v2.text2().setText(model.get_roll());
					v2.text3().setText(model.get_course());
					v2.text4().setText(model.get_date());
					//System.out.println(model.gettotal());
					String columnNames[] = { "SUBJECT", "NAME","TOTAL"};
					String dataValues[][] = { {v.gettext4().getText(),v.gettext5().getText(),""},{v.gettext6().getText(),v.gettext7().getText(),""},{v.gettext8().getText(),v.gettext9().getText(),""},{v.gettext10().getText(),v.gettext11().getText(),""},{v.gettext12().getText(),v.gettext13().getText(),model.gettotal()} };
					t = v2.tab() ;
					t = new JTable(dataValues, columnNames );
					v2.add(t);
					//v2.text5().setText(model.gettotal());
					ls.add(model);

				}
				
			}
}

public void control2(){
	
	v3.getbutton().addActionListener(new actionListener2());
}

class actionListener2 extends JFrame implements ActionListener {		
			public void actionPerformed(ActionEvent e){

				if(e.getSource()==v3.getbutton()){
					//v4 = new StudentView4();
					/*v4.text1().setText(model.get_name());
					v4.text2().setText(model.get_roll());
					v4.text3().setText(model.get_course());
					v4.text4().setText(model.get_date());
					//System.out.println(model.gettotal());
					String columnNames[] = { "SUBJECT", "NAME","TOTAL"};
					String dataValues[][] = { {v.gettext4().getText(),v.gettext5().getText(),""},{v.gettext6().getText(),v.gettext7().getText(),""},{v.gettext8().getText(),v.gettext9().getText(),""},{v.gettext10().getText(),v.gettext11().getText(),""},{v.gettext12().getText(),v.gettext13().getText(),model.gettotal()} };*/
				
                         }
}

}
    
public void control(){ 
/*annonymous class*/       
	
        actionListener = new ActionListener() {
              public void actionPerformed(ActionEvent e) {  
			
			if(e.getSource()==view.getButton1()){
				   v = new StudentView1();		
				 
				  //model.setmarks(v.gettext1().getText());
				  //this.control1();
				   control1();
				//  System.out.println);
				
				  
			}
			else{
				v3 = new StudentView3();
				control2();
			}
			
              
        }            
        
    };
	 view.getButton1().addActionListener(actionListener);
	 view.getButton2().addActionListener(actionListener);
     
    }

    public int get_student(String r){
		
		int flag = 0;
		for(int i=0;i<ls.size();i++)
			if(ls.get(i).get_roll().equals(r)){
				flag=i;
				break;
			}
		return flag;
	}
  
   
}



//package controller;

//import model.*;
//import view.*;

public class Student {
	public static void main(String[] args) {
		StudentModel sm = new StudentModel();
		StudentView sv = new StudentView();
		//StudentView1 sv1 = new StudentView1();
		StudentController sc = new StudentController(sm, sv);
		sc.control();
	}
}





	
	
	
		
