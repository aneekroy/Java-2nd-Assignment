
package student_new;

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import java.awt.event.*;
import java.awt.EventQueue;

import javax.swing.JFrame;

public class StudentView1 extends JFrame {

	private JFrame frame;
 JButton b1;
		
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentView1 window = new StudentView1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	/**
	 * Create the application.
	 */
	public StudentView1(studentModel M) {
		initialize(M);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(studentModel M) {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 JTextField textField;
		 JTextField txtRoll;
		 JLabel lblSubjects;
		 JLabel lblMarks;
		 JTextField textField_1;
		 JTextField textField_2;
		 JTextField textField_3;
		 JTextField textField_4;
		 JTextField textField_5;
		 JTextField textField_6;
		 JTextField textField_7;
		 JTextField textField_8;
		 JTextField textField_9;
		 JTextField textField_10;
			getContentPane().setLayout(null);
			
			JLabel lblNewLabel = new JLabel("Name of the Student\n");
			lblNewLabel.setBounds(54, 36, 147, 15);
			getContentPane().add(lblNewLabel);
			getContentPane().setLayout(new FlowLayout());
			
			textField = new JTextField(M.get_name());
			textField.setBounds(234, 34, 114, 19);
			getContentPane().add(textField);
			textField.setColumns(10);
			
			JLabel lblRoll = new JLabel("Roll");
			lblRoll.setBounds(98, 63, 70, 15);
			getContentPane().add(lblRoll);
			
			txtRoll = new JTextField(M.get_roll());
			txtRoll.setText(null);
			txtRoll.setBounds(234, 65, 114, 19);
			getContentPane().add(txtRoll);
			txtRoll.setColumns(10);
			
			lblSubjects = new JLabel("Subjects");
			lblSubjects.setBounds(64, 90, 70, 15);
			getContentPane().add(lblSubjects);
			
			lblMarks = new JLabel("Marks");
			lblMarks.setBounds(244, 90, 70, 15);
			getContentPane().add(lblMarks);
			
			textField_1 = new JTextField(M.ret_sub(0));
			textField_1.setBounds(51, 110, 114, 19);
			getContentPane().add(textField_1);
			textField_1.setColumns(10);
			
			textField_2 = new JTextField(M.ret_marks(0));
			textField_2.setBounds(234, 110, 114, 19);
			getContentPane().add(textField_2);
			textField_2.setColumns(10);
			
			textField_3 = new JTextField(M.ret_sub(1));
			textField_3.setBounds(54, 262, 114, 19);
			getContentPane().add(textField_3);
			textField_3.setColumns(10);
			
			textField_4 = new JTextField(M.ret_marks(1));
			textField_4.setBounds(234, 262, 114, 19);
			getContentPane().add(textField_4);
			textField_4.setColumns(10);
			
			textField_5 = new JTextField(M.ret_sub(2));
			textField_5.setBounds(54, 223, 114, 19);
			getContentPane().add(textField_5);
			textField_5.setColumns(10);
			
			textField_6 = new JTextField(M.ret_marks(2));
			textField_6.setBounds(234, 223, 114, 19);
			getContentPane().add(textField_6);
			textField_6.setColumns(10);
			
			textField_7 = new JTextField(M.ret_sub(3));
			textField_7.setBounds(54, 179, 114, 19);
			getContentPane().add(textField_7);
			textField_7.setColumns(10);
			
			textField_8 = new JTextField(M.ret_marks(3));
			textField_8.setBounds(234, 179, 114, 19);
			getContentPane().add(textField_8);
			textField_8.setColumns(10);
			
			textField_9 = new JTextField(M.ret_sub(4));
			textField_9.setBounds(54, 141, 114, 19);
			getContentPane().add(textField_9);
			textField_9.setColumns(10);
			
			textField_10 = new JTextField(M.ret_marks(4));
			textField_10.setBounds(234, 141, 114, 19);
			getContentPane().add(textField_10);
			textField_10.setColumns(10);
			
			b1 = new JButton("EXIT");
			add(b1);
			b1.addActionListener(new mylistener());
		
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setVisible(true);
			
					
	}
private class mylistener implements ActionListener{
		
		public void actionPerformed(ActionEvent e){
			
			if(e.getSource()==b1)
				System.exit(0);
			
		}
	}
/*	private JFrame getContentPane() {
		// TODO Auto-generated method stub
		return null;
	}
*/
}
