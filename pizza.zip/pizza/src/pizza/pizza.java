package pizza;

import java.util.*;

	interface topping {

		void addTopping();

	}

	class pepperoni implements topping{

		public void addTopping(){
			System.out.println("Pepperoni topping added.");
		}

	}

	class sausage implements topping{

		public void addTopping(){
			System.out.println("Sausage topping added.");
		}
		
	}

	class anchovy implements topping{

		public void addTopping(){
			System.out.println("Anchovy topping added.");
		}
		
	}

	abstract class abstractFactory{

		abstract public topping getTopping(String type);

	}

	class DominosConcreteFactory extends abstractFactory{

		public topping getTopping(String type){

			if (type.equalsIgnoreCase("Pepperoni"))
				return new pepperoni();

			else if (type.equalsIgnoreCase("Sausage"))
				return new sausage();

			else 
				return null;



		}


	}

	class PizzaHutConcreteFactory extends abstractFactory{

		public topping getTopping(String type){

			if (type.equalsIgnoreCase("Anchovy"))
				return new anchovy();

			else if (type.equalsIgnoreCase("Sausage"))
				return new sausage();

			else 
				return null;



		}


	}

public	class pizza{
		public static void main(String args[]){
			DominosConcreteFactory f1 = new DominosConcreteFactory();
			PizzaHutConcreteFactory f2 = new PizzaHutConcreteFactory();

			Scanner s = new Scanner(System.in);
			String choice ;
			String type;

			while (true){
				System.out.println("Order from==>");
				System.out.println("Factory from Dominos");
				System.out.println("Factory from PizzaHut");

				System.out.print("Your choice: ");
				choice = s.nextLine();

				if (choice.equalsIgnoreCase("Dominos")){
					System.out.println("\nOnly Pepperoni and Sausage Available !!");
					System.out.println("Enter the topping you want :");
					//s.nextLine();
					type = s.nextLine();
					topping top = f1.getTopping(type);
					if (top!=null){
						top.addTopping();
						System.out.println("Dominos - Pizza served.");
					}
					else{
						System.out.println("Sorry, no such topping found!");
					}

				}
				else if(choice.equalsIgnoreCase("PizzaHut")) {
					System.out.println("\nOnly Anchovy and Sausage Available !!");
					System.out.println("Enter the topping you want:");
					//s.nextLine();
					type = s.nextLine();
					topping top = f2.getTopping(type);
					if (top!=null){
						top.addTopping();
						System.out.println("PizzaHut - Pizza served.");
					}
					else{
						System.out.println("Sorry, no such topping found!");
					}

				}
				else {
					System.out.println("You've entered a wrong choice.");
				}

				System.out.print("Do you want to exit? Enter Y for yes,or N for NO :");
				choice =s.nextLine();
				if (choice.equalsIgnoreCase("Y"))
					break;
				else if(choice.equalsIgnoreCase("N"))
				{
				continue;
				}
				else
				{
				System.out.println("Wrong Choice !!");
				}
					
			} s.close();
		}
	}

